const fs = require('fs');

function exercise1(num, den) {
    return undefined;
}

function exercise2(day, month, year) {
    return undefined;
}

function exercise3(l) {
    return undefined;
}

function exercise4(word) {
    return undefined;
}

function exercise5(message) {
    return undefined;
}

function exercise6(num) {
    return undefined;
}

function exercise7(filename) {
    return undefined;
}

function exercise8(filename, length) {
    return undefined;
}

function exercise9(start, end, moves) {
    return undefined;
}

function exercise10(environment) {
    return undefined;
}

module.exports = {
    // Exercise 1
    exercise1: exercise1,

    // Exercise 2
    exercise2: exercise2,

    // Exercise 3
    exercise3: exercise3,

    // Exercise 4
    exercise4: exercise4,

    // Exercise 5
    exercise5: exercise5,

    // Exercise 6
    exercise6: exercise6,

    // Exercise 7
    exercise7: exercise7,

    // Exercise 8
    exercise8: exercise8,

    // Exercise 9
    exercise9: exercise9,

    // Exercise 10
    exercise10: exercise10,
}




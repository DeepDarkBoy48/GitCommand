# Commenting this function
def function1(value)
    print(value + 1)

# Commenting this other function
def function2(obj)
    return function1(obj.value) // 10
